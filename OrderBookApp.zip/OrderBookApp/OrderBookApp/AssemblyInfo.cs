[assembly: log4net.Config.XmlConfigurator(Watch = true)]
